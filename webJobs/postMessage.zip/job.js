var request = require('request');
request('http://valentino.azurewebsites.net/cupid/message');
